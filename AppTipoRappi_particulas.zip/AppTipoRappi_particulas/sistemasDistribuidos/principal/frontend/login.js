/* ═══════════════════════════════════════════════════
   login.js — App tipo Rappi (CONEXIÓN DOCKER)
═══════════════════════════════════════════════════ */

/* ── Partículas (Efecto Visual) ─────────────────── */
const canvas = document.getElementById('c');
const ctx = canvas.getContext('2d');
let W, H, pts = [];

function resize() {
    W = canvas.width = window.innerWidth;
    H = canvas.height = window.innerHeight;
}
resize();
window.addEventListener('resize', () => { resize(); initParticles(); });
function rand(a, b) { return a + Math.random() * (b - a); }

function initParticles() {
    pts = [];
    const n = Math.floor(W * H / 9000);
    for (let i = 0; i < n; i++) {
        pts.push({
            x: rand(0, W), y: rand(0, H),
            vx: rand(-0.25, 0.25), vy: rand(-0.4, -0.05),
            r: rand(0.8, 2.5), a: rand(0.1, 0.7),
            hue: rand(15, 40), pulse: rand(0, Math.PI * 2),
            ps: rand(0.01, 0.03)
        });
    }
}
initParticles();

let mx = -999, my = -999;
document.addEventListener('mousemove', e => { mx = e.clientX; my = e.clientY; });

function drawParticles() {
    ctx.clearRect(0, 0, W, H);
    for (const p of pts) {
        p.x += p.vx; p.y += p.vy; p.pulse += p.ps;
        const glow = 0.4 + 0.3 * Math.sin(p.pulse);
        if (p.y < -4) { p.y = H + 2; p.x = rand(0, W); }
        if (p.x < -4) p.x = W + 2;
        if (p.x > W + 4) p.x = -2;
        const dx = p.x - mx, dy = p.y - my;
        const d = Math.sqrt(dx * dx + dy * dy);
        if (d < 80) {
            const f = (80 - d) / 80 * 0.6;
            p.vx += (dx / d) * f * 0.015;
            p.vy += (dy / d) * f * 0.015;
        }
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r * (0.8 + 0.4 * glow), 0, Math.PI * 2);
        ctx.fillStyle = `hsla(${p.hue},90%,65%,${p.a * glow})`;
        ctx.fill();
    }
    requestAnimationFrame(drawParticles);
}
drawParticles();

/* ── UI — modo login / registro ─────────────────── */
let mode = 'login';
function toggleMode(m) {
    mode = m;
    document.getElementById('t-login').classList.toggle('on', m === 'login');
    document.getElementById('t-reg').classList.toggle('on', m === 'reg');
    document.getElementById('name-field').style.display = m === 'reg' ? 'block' : 'none';
    document.getElementById('mainbtn').textContent = m === 'login' ? 'Ingresar →' : 'Crear cuenta →';
}

function togglePwd() {
    const input = document.getElementById('pwd');
    input.type = input.type === 'password' ? 'text' : 'password';
}

function showToast(msg) {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 2400);
}

async function hacerLogin() {
    // 1. Capturamos los elementos
    const inputUsuario = document.getElementById("usuario");
    const inputPassword = document.getElementById("password");
    const btn = document.getElementById("mainbtn");

    // Verificación de seguridad: si no los encuentra, nos avisa por consola
    if (!inputUsuario || !inputPassword) {
        alert("Error técnico: No se encuentran los campos de texto.");
        return;
    }

    const usuario = inputUsuario.value.trim();
    const password = inputPassword.value.trim();

    if (!usuario || !password) {
        showToast("Escribe tu usuario y clave");
        return;
    }

    btn.disabled = true;
    btn.textContent = "Validando...";

    try {
        const resp = await fetch("/gateway/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ usuario, password })
        });

        const data = await resp.json();

        if (data.login === "ok") {
            window.location.href = "home.html";
        } else {
            showToast("Usuario o clave incorrectos");
            btn.disabled = false;
            btn.textContent = "Ingresar →";
        }
    } catch (error) {
        showToast("Servidor fuera de línea");
        btn.disabled = false;
        btn.textContent = "Ingresar →";
    }
}